import React from 'react';
import films from './films.json';
import {FilmDetails} from './FilmDetails';
import {ShowingDate} from './ShowingDate';
import {FilmsList} from './FilmsList';
import {Route} from 'react-router-dom';

function chooseDate(props) {
console.log("Chosen date", props);}


function chooseFilm(props)
{
console.log(props.title);}


export const LandingPage = () => (
<>
<h1>What do you want to see?</h1>
<ShowingDate pickDate={chooseDate}/>
<FilmsList films={films} chooseMovie={chooseFilm}/>
</>
);
