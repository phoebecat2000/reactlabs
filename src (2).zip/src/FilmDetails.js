import React from 'react';

export const FilmDetails = () => (
<>
<p>
Notting Hill
<li>1:00</li>
<li>4:00</li>
<li>6:00</li>
<img src="../img/posters/1.jpg" alt="Poster"></img>
<div>Movie description</div>
</p>
</>
);