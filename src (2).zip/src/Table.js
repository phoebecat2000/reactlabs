import React from 'react';
import {Seat} from './Seat';
export const Table = (props) => (
<>

  <table border ="1" width="500">
    <tr>
      <th>Theater Id</th>
      <th>Table Number</th>
      <th>Seats</th>
    </tr>
    <tr>
      <td width ="60">
                         {props.table.theater_id}
                       </td>
       <td width="60">
                     {props.table.table_number}
                   </td>
                    <td>
                    {props.table.seats.map( s => <Seat Seat={s} SelectSeat={props.selectSeat} />)
                    }
                                </td>
    </tr>
  </table>
</>
);