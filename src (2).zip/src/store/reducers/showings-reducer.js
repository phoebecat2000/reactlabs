//import { actionTypes } from '../actions';

const showingsReducer = (state = [], action) => {
  if (!action) return state;
  switch (action.type) {
    default:
      return state;
  }
}

export default showingsReducer;