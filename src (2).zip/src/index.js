import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import "material-design-lite/material.js";
import {BrowserRouter} from 'react-router-dom';
import {Route} from 'react-router-dom';
import {LandingPage} from './LandingPage';
import {PickSeats} from './PickSeats';
import {Login} from './Login';
import {Checkout} from './Checkout';
import {NotFound} from './NotFound';

ReactDOM.render(<BrowserRouter>
<switch>
<Route exact path="/" component={LandingPage}/>
<Route exact  path="/PickSeats/:showing_id" component={PickSeats}/>
<Route exact path="/Checkout" component={Checkout}/>
<Route exact path="/Login" component={Login}/>
<Route component={NotFound}/>
</switch>

</BrowserRouter>, document.getElementById('root'));


// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
