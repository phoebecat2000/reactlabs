import React from 'react';
import {Film} from './Film';


export const FilmsList = (props) => (
<>
<section className="filmsList">
<Film chooseMovie={props.chooseMovie} film={props.films[0]} />
<Film chooseMovie={props.chooseMovie} film={props.films[1]} />
<Film chooseMovie={props.chooseMovie} film={props.films[2]} />
<Film chooseMovie={props.chooseMovie} film={props.films[3]} />
</section>
</>

);