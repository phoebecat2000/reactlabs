import React from 'react';
import "material-design-lite/material.js"

const inputStyle = {
backgroundColor:"red"};
function login()
{
console.log("Clicked on Login button");
}
export const Login = () => (
<>
<h1>Log in</h1>
 E-mail:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;    &nbsp;&nbsp;
 <input type="email" name="email"/><br/>
User password:
<input  type="password" name="psw"/><br/>
<input style={inputStyle} type="submit" value="Login" onClick={login}/>
</>
);