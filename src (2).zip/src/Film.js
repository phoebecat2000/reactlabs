import React from 'react';
import {posterStyle, imgStyle} from './LandingPage.css.js';

export const Film = (props) => (
<>
<section className="films" onClick={() => props.chooseMovie(props.film)}>
<img src={props.film.poster_path} alt={props.film.title} style={imgStyle}></img>
<h3>{props.film.title}</h3>
<p>{props.film.tagline}</p>
</section>
</>

);