import React from 'react';
export const Seat = (props) => (

<>
 <input type="checkbox" name={props.Seat} value={props.Seat} onClick={props.SelectSeat}></input>{props.Seat}
</>
);