
export const style = {border: "1px solid #ddd"};
export const posterStyle = {width:"300px"};
export const imgStyle ={ border: "1px solid #ddd",  borderRadius: "4px", padding: "5px", width: "150px"};
