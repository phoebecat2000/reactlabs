import React from 'react';
function checkout()
{
console.log("checkout out");
}

export const Checkout = () => {
return (
<>
<h1>Checkout</h1>
<table>
  <tr>
    <th>Item</th>
    <th>Price</th>
    <th>Quantity</th>
    <th>Quantity</th>
  </tr>
  <tr>
    <td>PostOak-Table1S2</td>
    <td>15 $</td>
    <td>1</td>
    <td>15 $</td>
  </tr>
  <tr>
    <td>SubTotal</td>
    <td> </td>
    <td> </td>
    <td>15 $</td>
  </tr>
    <tr>
      <td>tax</td>
      <td> </td>
      <td> </td>
      <td>2 $</td>
    </tr>
        <tr>
          <td>Total</td>
          <td> </td>
          <td> </td>
          <td>17 $</td>
        </tr>

</table>
<input type="submit" value="Purchase" onClick={checkout}/><pre>
<a href="http://localhost:3000">Keep Shopping</a></pre>
</>
)
};