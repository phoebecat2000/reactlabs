import React from 'react';


export const ShowingDate = (props) => (
 <>
<input type="date" onChange={(event) => props.pickDate(event.target.value)}/>
</>

);