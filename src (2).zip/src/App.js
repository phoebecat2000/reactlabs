import React from 'react';
import logo from './logo.svg';
import './App.css';
import {LandingPage} from './LandingPage';
import {PickSeats} from './PickSeats';
import {Login} from './Login';
import {Checkout} from './Checkout';
import '../node_modules/material-design-lite/material.min.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
        <Login/>
		<LandingPage/>
		<PickSeats/>
		<Checkout/>

        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>		
      </header>
	 
    </div>
	
  );
}

export default App;
