import React from 'react';
import {Checkout} from './Checkout';
import theaters from './theaters.json';
import {Table} from './Table';

function goToCheckout() {
console.log("checking out");

}

function selectSeat()
{
console.log("Selected Seat");}


const tables = [{id:1, theater_id:1, table_number:1,seats:[1,2,3,4]},
                {id:2, theater_id:1, table_number:2,seats:[5,6,7,8]},
                {id:3, theater_id:2, table_number:1,seats:[1,2,3,4]}
               ];

export const PickSeats = (props) => {
console.log("Param");

return(<>

<h1>Where would you like to sit?</h1>
{
tables.map((t) => <Table table={t} selectSeat={selectSeat}/>)
}

 <button  className="mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored" style={{padding:"16px 85px"}}
  name="CheckOut" value="Checkout" onClick={goToCheckout}>
   <i class="material-icons">checkout</i>
 </button>

</>)
};
